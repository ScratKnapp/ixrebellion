ITEM.name = "Wound Counter"
ITEM.description = "Used to effectively keep track of your character's wounds. Don't drop this, maybe."
ITEM.model = Model("models/props_c17/gravestone002a.mdl")
ITEM.category = "Wounds"

ITEM.invWidth = 5
ITEM.invHeight = 2

ITEM.Width = 1
ITEM.Height = 1