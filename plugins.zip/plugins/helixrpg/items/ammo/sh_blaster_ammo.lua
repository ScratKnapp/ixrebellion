ITEM.name = "Blaster Ammo"
ITEM.model = "models/items/combine_rifle_cartridge01.mdl"
ITEM.ammo = "ar2" -- type of the ammo
ITEM.ammoAmount = 100 -- amount of the ammo
ITEM.description = "A Cartridge that contains blaster ammo."
