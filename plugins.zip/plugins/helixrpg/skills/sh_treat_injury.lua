SKILL.name = "Treat Injury"
SKILL.description = "medpack."