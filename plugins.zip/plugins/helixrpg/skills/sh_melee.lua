SKILL.name = "Melee"
SKILL.description = "How skilled you are with a melee weapon."