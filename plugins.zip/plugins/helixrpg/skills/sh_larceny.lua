SKILL.name = "Larceny"
SKILL.description = "Your aptitude for breaking into things and general wrongdoing."