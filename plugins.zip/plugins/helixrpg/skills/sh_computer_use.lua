SKILL.name = "Computer Use"
SKILL.description = "How good you are with computers and technology."