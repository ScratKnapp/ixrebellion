SKILL.name = "Marksmanship"
SKILL.description = "Your measure of accuracy when using ranged weapons."