SKILL.name = "Stealth"
SKILL.description = "Must've been the wind."