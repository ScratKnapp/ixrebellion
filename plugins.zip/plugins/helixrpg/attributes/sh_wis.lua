ATTRIBUTE.name = "Wisdom"
ATTRIBUTE.description = "Determines your wit and cleverness."