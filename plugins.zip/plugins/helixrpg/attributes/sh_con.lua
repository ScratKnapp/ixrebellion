ATTRIBUTE.name = "Constitution"
ATTRIBUTE.description = "Determines your overall endurance and toughness."