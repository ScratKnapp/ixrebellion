TRAIT.name = "Operator"
TRAIT.description = "You take pride in your well drilled and methodical approach. Your fighting isn't defined by flashy moves or ostentatious weaponry, it's defined by effective and efficient use of small arms."
TRAIT.icon = "icon16/find.png"