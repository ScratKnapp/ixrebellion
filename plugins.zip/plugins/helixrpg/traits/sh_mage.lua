TRAIT.name = "Mage"
TRAIT.description = "You don't just study the arcane, you command its power. Your power is defined by the manipulation of magic inside and out of combat."
TRAIT.icon = "icon16/wand.png"