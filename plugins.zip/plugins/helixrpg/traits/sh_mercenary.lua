TRAIT.name = "Mercenary"
TRAIT.description = "Some call you a cold blooded killer. But you prefer being called a professional."
TRAIT.icon = "icon16/box.png"