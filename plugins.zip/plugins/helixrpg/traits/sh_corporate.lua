TRAIT.name = "Corporate"
TRAIT.description = "Cut throat business practices have always been your specialty. The bleedingn necks of your competitors can attest to that."
TRAIT.icon = "icon16/money.png"