TRAIT.name = "Scoundrel"
TRAIT.description = "You've spent a lot of time outside of prying eyes, and can navigate the seedy underground better because of it."
TRAIT.icon = "icon16/user_gray.png"