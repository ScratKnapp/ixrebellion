TRAIT.name = "Rogue"
TRAIT.description = "Your approach is patient, precise, and lethal. Not that anyone would know, you've never been caught. Your fighting is defined by stealth, guile, and the use of concealable one handed weapons."
TRAIT.icon = "icon16/briefcase.png"