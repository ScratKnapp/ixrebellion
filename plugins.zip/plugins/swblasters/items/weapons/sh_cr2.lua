ITEM.name = "CR-2"
ITEM.description = "A fast-firing heavy blaster pistol manufactured by Corellian Arms. Antiquated, but reliable."
ITEM.model = "models/sw_battlefront/weapons/cr2_pistol.mdl"
ITEM.class = "rw_sw_cr2"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}