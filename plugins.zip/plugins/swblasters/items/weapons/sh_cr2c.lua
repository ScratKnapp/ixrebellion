ITEM.name = "CR-2c"
ITEM.description = "A sibling model to the CR-2 heavy blaster pistol, modified to utilize a stock as a carbine."
ITEM.model = "models/sw_battlefront/weapons/cr2_pistol.mdl"
ITEM.class = "rw_sw_cr2c"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}