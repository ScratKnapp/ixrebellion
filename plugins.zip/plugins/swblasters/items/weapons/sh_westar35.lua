ITEM.name = "Westar-35"
ITEM.description = "An infamous Mandalorian blaster pistol, often used in conjunction with the Westar-11. Has a low maintenance construction and is as much an art piece as it is a weapon."
ITEM.model = "models/sw_battlefront/weapons/westar_35_pistol.mdl"
ITEM.class = "rw_sw_westar35"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}