ITEM.name = "DT-12s Akimbo"
ITEM.description = "Stolen from the coolest cop on the force."
ITEM.model = "models/hauptmann/star wars/weapons/ddt12.mdl"
ITEM.class = "rw_sw_dual_dt12"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}