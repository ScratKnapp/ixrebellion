PLUGIN.name = "Star Wars Blasters"
PLUGIN.author = "fellas"