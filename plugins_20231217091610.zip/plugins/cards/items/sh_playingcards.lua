ITEM.name = "A deck of playing cards"
ITEM.description = "A deck of playing cards missing the two jokers. (/draw to pull a card)"
ITEM.price = 0
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.skin = 1