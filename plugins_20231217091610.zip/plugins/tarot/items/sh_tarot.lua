ITEM.name = "Tarot Deck"
ITEM.description = "A deck of the Major Arcana, used for tarot readings. (/Tarot)"
ITEM.price = 0
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.skin = 1