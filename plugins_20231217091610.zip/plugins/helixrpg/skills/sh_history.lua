SKILL.name = "History"
SKILL.description = "A measure for your character's Historic aptitude."