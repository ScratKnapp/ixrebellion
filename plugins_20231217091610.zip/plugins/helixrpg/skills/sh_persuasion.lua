SKILL.name = "Persuasion"
SKILL.description = "A measure for your character's Persuasion aptitude."