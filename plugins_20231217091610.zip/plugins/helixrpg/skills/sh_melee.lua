SKILL.name = "Melee"
SKILL.description = "A measure for your character's Melee aptitude."