SKILL.name = "Acrobatics"
SKILL.description = "A measure for your character's Acrobatic aptitude."