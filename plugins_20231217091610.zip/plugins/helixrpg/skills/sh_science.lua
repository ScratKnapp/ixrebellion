SKILL.name = "Science"
SKILL.description = "A measure for your character's Scientific aptitude."