SKILL.name = "Insight"
SKILL.description = "A measure for your character's Insight aptitude."