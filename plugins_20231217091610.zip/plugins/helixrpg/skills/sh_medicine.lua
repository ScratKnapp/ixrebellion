SKILL.name = "Medicine"
SKILL.description = "A measure for your character's Medical aptitude."