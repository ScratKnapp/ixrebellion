SKILL.name = "Electronics"
SKILL.description = "A measure for your character's Electronic aptitude."