SKILL.name = "Marksmanship"
SKILL.description = "A measure for your character's Marksman aptitude."