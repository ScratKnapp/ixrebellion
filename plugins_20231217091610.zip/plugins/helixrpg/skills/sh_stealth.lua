SKILL.name = "Stealth"
SKILL.description = "A measure for your character's Stealth aptitude."