LINEAGE.name = "Quarian"
LINEAGE.description = "The quarians are a nomadic species of humanoid aliens known for their skills with technology and synthetic intelligence. Since their homeworld Rannoch was conquered, the quarians live aboard the Migrant Fleet, a huge collection of starships that travels as a single fleet.

Approximately three hundred years before the events of 2183, the quarians created the geth, a species of rudimentary artificial intelligences, to serve as an efficient source of manual labor. However, when the geth gradually became sentient, the quarians became terrified of possible consequences and tried to destroy their creations. The geth won the resulting war and forced their creators into exile. Now the quarians wander the galaxy in a flotilla of salvaged ships, secondhand vessels, and recycled technology."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}