LINEAGE.name = "Salarian"
LINEAGE.description = "The second species to join the Citadel, the salarians are warm-blooded amphibians native to the planet Sur'Kesh. Salarians possess a hyperactive metabolism; they think fast, talk fast, and move fast. To salarians, other species seem sluggish and dull-witted, especially the elcor. Unfortunately, their metabolic speed leaves them with a relatively short lifespan; salarians over the age of 40 are a rarity.

Salarians are known for their observational capability and non-linear thinking. This manifests as an aptitude for research and espionage. They are constantly experimenting and inventing, and it is generally accepted that they always know more than they are letting on."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}