LINEAGE.name = "Krogan"
LINEAGE.description = "The krogan are a species of large reptilian bipeds native to the planet Tuchanka, a world known for its harsh environments, scarce resources, and overabundance of vicious predators. The krogan managed to not only survive on their unforgiving homeworld, but actually thrived in the extreme conditions. Unfortunately, as krogan society became more technologically advanced, so did their weaponry. The end result is that they destroyed their homeworld in a nuclear war that reduced their race into primitive warring tribes.

With the help of the salarians, the krogan were 'uplifted' into galactic society, and lent their numbers and military prowess to bring an end to the Rachni Wars. Ironically, after the rachni were eradicated, the rapidly-expanding krogan became a threat to the galaxy in turn, starting the Krogan Rebellions and forcing the turians to unleash the genophage. This genetic 'infection' dramatically reduced fertility in krogan females, causing a severe drop in births secondary to prenatal and postnatal death and, ultimately eliminating the krogan's numerical advantage."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}