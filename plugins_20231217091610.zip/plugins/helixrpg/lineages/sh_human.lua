LINEAGE.name = "Human"
LINEAGE.description = "Humans, from the planet Earth, are the newest sentient species of notable size to enter the galactic stage and are the most rapidly expanding and developing. They independently discovered a Prothean data cache on Mars in 2148, and the mass relay networks shortly thereafter."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}