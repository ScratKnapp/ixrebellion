LINEAGE.name = "Turian"
LINEAGE.description = "Known for their militaristic and disciplined culture, the turians were the third race to join the Citadel Council. They gained their Council seat after defeating the hostile krogan for the Council during the Krogan Rebellions. The turians deployed a salarian-created biological weapon called the genophage, which virtually sterilised the krogan and sent them into a decline. The turians then filled the peacekeeping niche left by the once-cooperative krogan, and eventually gained a Council seat in recognition of their efforts.

Originally from the planet Palaven, turians are best known for their military role, particularly their contributions of soldiers and starships to the Citadel Fleet. They are respected for their public service ethic—it was the turians who first proposed creating C-Sec—but are sometimes seen as imperialist or rigid by other races. There is some animosity between turians and humans, largely due to the turian role in the First Contact War. This bitterness is slowly beginning to heal—as shown by the cooperation of the two races on the construction of the SSV Normandy—but many turians still resent humans, and vice versa."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}