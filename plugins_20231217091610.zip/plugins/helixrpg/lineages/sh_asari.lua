LINEAGE.name = "Asari"
LINEAGE.description = "The asari, native to the planet Thessia, are often considered the most influential and respected sentient species in the galaxy, and are known for their elegance, diplomacy, and biotic aptitude. This is partly due to the fact that the asari were among the earliest races to achieve interstellar flight after the Protheans, and the first to discover and settle the Citadel.

A mono-gender race, the asari are distinctly feminine in appearance and possess maternal instincts. Their unique physiology, expressed in a millennium-long lifespan and the ability to reproduce with a partner of any gender or species, gives them a conservative yet convivial attitude toward other races. Favoring compromise and cooperation over conflict, the asari were instrumental in proposing and founding the Citadel Council and have been at the heart of galactic society ever since."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}