FEAT.name = "Armor Proficiency: Light"
FEAT.description = "I don't even know what to write here."
FEAT.icon = "icon16/user_gray.png"