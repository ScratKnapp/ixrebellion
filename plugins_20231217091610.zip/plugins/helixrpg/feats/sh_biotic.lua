FEAT.name = "Biotic"
FEAT.description = "Gifted with the ability to use biotic powers. You are a force to be reckoned with, if you want to be."
FEAT.icon = "icon16/user_gray.png"