FEAT.name = "Weapon Proficiency: Assault Rifle"
FEAT.description = "You are proficient with assault rifles and can use them to great effect."
FEAT.icon = "icon16/user_gray.png"