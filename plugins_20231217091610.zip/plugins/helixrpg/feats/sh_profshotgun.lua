FEAT.name = "Weapon Proficiency: Shotguns"
FEAT.description = "You are proficient with shotguns and people within range are terrified of you."
FEAT.icon = "icon16/user_gray.png"