FEAT.name = "Armor Proficiency: Medium"
FEAT.description = "You like to keep things well-rounded. Moderation is key, after all."
FEAT.icon = "icon16/user_gray.png"