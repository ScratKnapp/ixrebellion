ITEM.name = "DL-18"
ITEM.description = "The cheapest pistol on the market, but plasma is plasma."
ITEM.model = "models/hauptmann/star wars/weapons/dl18.mdl"
ITEM.class = "rw_sw_dl18"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}