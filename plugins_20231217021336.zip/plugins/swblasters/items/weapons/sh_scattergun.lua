ITEM.name = "Scattergun"
ITEM.description = "A low-velocity slugthrower that fires a spray of solid pellets. Hand-loaded, and best used in close range due to pellet scatter."
ITEM.model = "models/kuro/sw_battlefront/weapons/bf1/scattergun.mdl"
ITEM.class = "rw_sw_scattershotgun"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}