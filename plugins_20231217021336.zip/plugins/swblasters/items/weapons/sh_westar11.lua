ITEM.name = "Westar-34"
ITEM.description = "An infamous Mandalorian blaster pistol, known for its ease of drawing and heat-absorbant design. Built small enough to fit within most jetpack compartments."
ITEM.model = "models/cs574/weapons/westar34.mdl"
ITEM.class = "rw_sw_westar34"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}