ITEM.name = "Z-6 Rotary Cannon"
ITEM.description = "A powerful rotating blaster cannon made famous thanks to its use during the Clone Wars. This particular weapon is a surplus Clone weapon; you can just barely make out the emblem of the Republic emblazoned on the body of the cannon."
ITEM.model = "models/z6_rotatory_blaster_cannon.mdl"
ITEM.class = "rw_sw_z6"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}