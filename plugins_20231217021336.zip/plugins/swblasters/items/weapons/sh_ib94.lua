ITEM.name = "IB-94"
ITEM.description = "A rare model of blaster pistol most often seen in the hands of independent Mandalorians. Very light and dependable."
ITEM.model = "models/cs574/weapons/dc92.mdl"
ITEM.class = "rw_sw_ib94"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}