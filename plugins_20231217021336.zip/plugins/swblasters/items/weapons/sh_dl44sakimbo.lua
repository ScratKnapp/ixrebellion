ITEM.name = "DL-44s Akimbo"
ITEM.description = "What's better than one highly illegal sidearm? Two of them."
ITEM.model = "models/sw_battlefront/weapons/dl44_pistol_ext.mdl"
ITEM.class = "rw_sw_dual_dl44"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}