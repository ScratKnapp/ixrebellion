ITEM.name = "Security S-5"
ITEM.description = "A heavy blaster pistol most notably used by Naboo's Security Forces. Fitted with an underbarrel dart launcher."
ITEM.model = "models/sw_battlefront/weapons/s5_pistol.mdl"
ITEM.class = "rw_sw_s5c"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}