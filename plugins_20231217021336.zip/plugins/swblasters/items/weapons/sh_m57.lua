ITEM.name = "M-57"
ITEM.description = "Best known as the DL-44's competing twin. Just as powerful, but produced primarily with metal to be legal within the Empire."
ITEM.model = "models/sw_battlefront/weapons/dl44_pistol_ext.mdl"
ITEM.class = "rw_sw_m57"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}