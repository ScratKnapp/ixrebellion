ITEM.name = "IB-94S"
ITEM.description = "A modified IB-94 set with a canted scope. Slightly heavier than its sibling, and whoever mounted the scope clearly hates lefties."
ITEM.model = "models/cs574/weapons/dc92s.mdl"
ITEM.class = "rw_sw_ib94s"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}