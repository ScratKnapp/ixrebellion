ITEM.name = "UMB-1"
ITEM.description = "An assault blaster used exclusively by native Umbaran soldiers. Strong enough to incapacitate Clonetroopers in a single shot."
ITEM.model = "models/jay/unbaran_gun.mdl"
ITEM.class = "rw_sw_umb1"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}