ITEM.name = "X-8 Night Sniper"
ITEM.description = "A long range blaster pistol notorious for its silent firing. Unusual for many blasters, it seems to be most comfortably used in the left hand."
ITEM.model = "models/hauptmann/star wars/weapons/x8_sniper.mdl"
ITEM.class = "rw_sw_x8"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}