ITEM.name = "IQA-11"
ITEM.description = "A sleek and inexpensive sniper rifle. Though not as powerful as some of its competitors, it makes a good starter rifle."
ITEM.model = "models/sw_battlefront/weapons/iqa11_rifle.mdl"
ITEM.class = "rw_sw_iqa11"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}