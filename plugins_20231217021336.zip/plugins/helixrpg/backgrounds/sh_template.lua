BACKGROUND.name = ""
BACKGROUND.description = ""
BACKGROUND.icon = "icon16/user.png"
BACKGROUND.traits = {
--	""
}