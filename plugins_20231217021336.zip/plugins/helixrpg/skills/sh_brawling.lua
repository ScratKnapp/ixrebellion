SKILL.name = "Brawling"
SKILL.description = "How good you are at unarmed combat."