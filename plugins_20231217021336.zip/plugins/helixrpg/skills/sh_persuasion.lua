SKILL.name = "Persuasion"
SKILL.description = "How persuasive you are to Non-Player Characters."