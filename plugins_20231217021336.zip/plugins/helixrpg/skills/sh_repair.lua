SKILL.name = "Repair"
SKILL.description = "Wooowwweeee Lego Blocks."