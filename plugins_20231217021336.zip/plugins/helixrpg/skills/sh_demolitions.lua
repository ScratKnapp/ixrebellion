SKILL.name = "Demolitions"
SKILL.description = "Cut the red wire. Do it."