SKILL.name = "Awareness"
SKILL.description = "A measurement of your attentiveness and overall perception."