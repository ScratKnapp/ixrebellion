LANGUAGE = {
	chooseSkills = "refine your skillset",
	chooseBackground = "shape your story",
	background = "Background",
	skills = "Skills",
	traits = "Traits",
	errorInvalidStat = "Provided stat is invalid."
}