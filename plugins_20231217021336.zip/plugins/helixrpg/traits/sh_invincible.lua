TRAIT.name = "Invincible"
TRAIT.description = "Test."
TRAIT.icon = "icon16/briefcase.png"