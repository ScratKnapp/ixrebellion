TRAIT.name = "Gunslinger"
TRAIT.description = "You take a unique approach to gunfighting. Rather than limit yourself to a single gun, you define your fighting style by fighting with one in each hand."
TRAIT.icon = "icon16/bomb.png"