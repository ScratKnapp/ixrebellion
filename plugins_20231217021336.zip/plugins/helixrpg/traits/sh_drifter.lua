TRAIT.name = "Drifter"
TRAIT.description = "You were always an outsider, so you tend to find yourself among other outcasts."
TRAIT.icon = "icon16/car.png"