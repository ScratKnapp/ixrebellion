ATTRIBUTE.name = "Dexterity"
ATTRIBUTE.description = "Determines your nimbleness and grace."