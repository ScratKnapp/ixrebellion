ATTRIBUTE.name = "Charisma"
ATTRIBUTE.description = "Determines how persuasive you can be."