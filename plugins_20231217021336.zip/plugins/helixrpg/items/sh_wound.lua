ITEM.name = "Wound"
ITEM.description = "One of your character's (hopefully) many wounds! Treat it well."
ITEM.model = Model("models/Gibs/HGIBS.mdl")
ITEM.category = "Wounds"


ITEM.functions.toggle = { -- sorry, for name order.
	name = "Toggle",
	tip = "useTip",
	icon = "icon16/connect.png",
	OnRun = function(item)
		local status = item:GetData("equip", false)
		local char = item.player:GetCharacter()

		item.player:EmitSound("buttons/button14.wav", 70, 150)
    
	if status then -- Checks to see if the radio is on.
			char:SetData("RadioInfo", nil) -- Removes RadioInfo from the player's data
			item:SetData("equip", false)
		else
			local radioInfo = { -- Sets up RadioInfo for player's data
				lastFreq = item.defaultFreq,
				freqList = item.freqList
			}

			char:SetData("RadioInfo", radioInfo)
			item:SetData("equip", true)
		end

		return false
	end,
	
	if (CLIENT) then
	function ITEM:PaintOver(item, w, h)
		if item:GetData("equip", false) then
			surface.SetDrawColor(110, 255, 110, 100)
		else
			surface.SetDrawColor(255, 110, 110, 100)
		end

		surface.DrawRect(w - 14, h - 14, 8, 8)
	end
end
  
}