FEAT.name = "Weapon Proficiency: Heavy Pistols"
FEAT.description = "You've learned the recoil and weight of heavier pistols, allowing you to use and fire them with deadly accuracy."
FEAT.icon = "icon16/user_gray.png"