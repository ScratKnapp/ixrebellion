FEAT.name = "Weapon Proficiency: Heavy Weapons"
FEAT.description = "You have an unusual relationship with your gun."
FEAT.icon = "icon16/user_gray.png"