FEAT.name = "Weapon Proficiency: Pistols"
FEAT.description = "You are proficient with standard issue pistols. Everyone is, right?"
FEAT.icon = "icon16/user_gray.png"