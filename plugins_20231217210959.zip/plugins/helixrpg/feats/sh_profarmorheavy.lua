FEAT.name = "Armor Proficiency: Heavy"
FEAT.description = "Someone once asked you what your favorite kinetic shield module was. Your answer? Pauldrons."
FEAT.icon = "icon16/user_gray.png"