FEAT.name = "Weapon Proficiency: Submachine Guns"
FEAT.description = "Concealable and deadly."
FEAT.icon = "icon16/user_gray.png"