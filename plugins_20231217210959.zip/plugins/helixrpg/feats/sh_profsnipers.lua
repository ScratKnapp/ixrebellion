FEAT.name = "Weapon Proficiency: Sniper Rifles"
FEAT.description = "Seldom do your enemies know where you are, and when they do, it's often too late."
FEAT.icon = "icon16/user_gray.png"