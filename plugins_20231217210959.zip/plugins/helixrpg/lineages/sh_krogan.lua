LINEAGE.name = "Krogan"
LINEAGE.description = "The krogan are a species of large reptilian bipeds native to the planet Tuchanka, a world known for its harsh environments, scarce resources, and overabundance of vicious predators. The krogan managed to not only survive on their unforgiving homeworld, but actually thrived in the extreme conditions. Unfortunately, as krogan society became more technologically advanced, so did their weaponry. The end result is that they destroyed their homeworld in a nuclear war that reduced their race into primitive warring tribes."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}