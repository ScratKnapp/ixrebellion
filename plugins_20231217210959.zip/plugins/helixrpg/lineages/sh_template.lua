LINEAGE.name = ""
LINEAGE.description = ""
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}