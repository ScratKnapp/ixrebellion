LINEAGE.name = "Drell"
LINEAGE.description = "The drell are a reptile-like race that were rescued from their dying homeworld by the hanar following first contact between the two. Since then, the drell have remained loyal to the hanar for their camaraderie and have fit comfortably into galactic civilization."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}