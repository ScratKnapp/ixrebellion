LINEAGE.name = "Quarian"
LINEAGE.description = "The quarians are a nomadic species of humanoid aliens known for their skills with technology and synthetic intelligence. Since their homeworld Rannoch was conquered, the quarians live aboard the Migrant Fleet, a huge collection of starships that travels as a single fleet."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}