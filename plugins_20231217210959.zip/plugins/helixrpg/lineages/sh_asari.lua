LINEAGE.name = "Asari"
LINEAGE.description = "The asari, native to the planet Thessia, are often considered the most influential and respected sentient species in the galaxy, and are known for their elegance, diplomacy, and biotic aptitude. This is partly due to the fact that the asari were among the earliest races to achieve interstellar flight after the Protheans, and the first to discover and settle the Citadel."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}