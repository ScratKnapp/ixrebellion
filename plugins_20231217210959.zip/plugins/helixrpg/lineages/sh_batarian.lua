LINEAGE.name = "Batarian"
LINEAGE.description = "A race of four-eyed bipeds native to the world of Khar'shan, the batarians are a disreputable species that chose to isolate itself from the rest of the galaxy. The Terminus Systems are infested with batarian pirate gangs and slaving rings, fueling the stereotype of the batarian thug. It should be noted that these criminals do not represent average citizens, who are forbidden to leave batarian space by their ubiquitous and paranoid government."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}