LINEAGE.name = "Turian"
LINEAGE.description = "Known for their militaristic and disciplined culture, the turians were the third race to join the Citadel Council. They gained their Council seat after defeating the hostile krogan for the Council during the Krogan Rebellions. The turians deployed a salarian-created biological weapon called the genophage, which virtually sterilised the krogan and sent them into a decline. The turians then filled the peacekeeping niche left by the once-cooperative krogan, and eventually gained a Council seat in recognition of their efforts."
LINEAGE.icon = "icon16/user.png"
LINEAGE.feats = {
--	""
}