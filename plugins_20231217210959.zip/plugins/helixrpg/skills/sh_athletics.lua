SKILL.name = "Athletics"
SKILL.description = "A measure for your character's Athletic aptitude."