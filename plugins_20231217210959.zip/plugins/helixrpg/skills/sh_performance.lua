SKILL.name = "Performance"
SKILL.description = "A measure for your character's Performance aptitude."