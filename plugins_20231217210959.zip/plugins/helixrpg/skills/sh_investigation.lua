SKILL.name = "Investigation"
SKILL.description = "A measure for your character's Investigation aptitude."