SKILL.name = "Engineering"
SKILL.description = "A measure for your character's Engineering aptitude."