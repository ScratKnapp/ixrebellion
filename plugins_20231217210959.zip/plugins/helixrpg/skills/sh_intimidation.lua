SKILL.name = "Intimidation"
SKILL.description = "A measure for your character's Intimidation aptitude."