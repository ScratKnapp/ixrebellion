SKILL.name = "Deception"
SKILL.description = "A measure for your character's Deceptive aptitude."