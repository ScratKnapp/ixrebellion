SKILL.name = "Brawling"
SKILL.description = "A measure for your character's Brawling aptitude."