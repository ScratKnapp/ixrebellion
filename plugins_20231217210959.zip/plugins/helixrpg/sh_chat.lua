-- [[ COMMANDS ]] --

--[[
	CHAT: rollgeneric
	DESCRIPTION: Highlights generic rolls made with arbitrary dice and bonuses.
]]--

ix.chat.Register("rollgeneric", {
	format = "** %s has rolled %s %s on their roll.", 
	color = Color(255, 185, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(self.color, string.format(self.format,
			speaker:GetName(), text, data.roll
		))
	end
})

--[[
	CHAT: roll20
	DESCRIPTION: Highlights rolls made with a d20.
]]--

ix.chat.Register("roll20", {
	format = "** %s has rolled %s on their %s roll.",
	color = Color(255, 125, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(self.color, string.format(self.format,
			speaker:GetName(), text, data.rolltype
		))
	end
})

--[[
	CHAT: roll20attack
	DESCRIPTION: Highlights attack rolls made with a d20.
]]--

ix.chat.Register("roll20attack", {
	format = "** %s has rolled %s on their Attack roll for %s damage.", --"** %s has rolled %s on their Attack roll for %s %s damage."
	color = Color(255, 70, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(data.color or self.color, string.format(self.format,
			speaker:GetName(), text, data.damage
		))
	end
})

--[[
	CHAT: roll20melee
	DESCRIPTION: Highlights melee attack rolls.
]]--

ix.chat.Register("roll20melee", {
	format = "** %s has rolled %s on their Melee Attack roll.",
	color = Color(255, 125, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(self.color, string.format(self.format,
			speaker:GetName(), text, data.rolltype
		))
	end
})

--[[
	CHAT: roll20firearms
	DESCRIPTION: Highlights firearm attack rolls.
]]--

ix.chat.Register("roll20firearms", {
	format = "** %s has rolled %s on their Firearms Attack roll.",
	color = Color(255, 125, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(self.color, string.format(self.format,
			speaker:GetName(), text, data.rolltype
		))
	end
})

--[[
	CHAT: roll20bfirearmsburst
	DESCRIPTION: Highlights firearm attack rolls.
]]--

ix.chat.Register("roll20firearmsburst1", {
	format = "** %s has rolled %s on their Firearms Burst Attack roll.",
	color = Color(255, 125, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(self.color, string.format(self.format,
			speaker:GetName(), text, data.rolltype
		))
	end
})

ix.chat.Register("roll20firearmsburst2", {
	format = "** %s has rolled %s on their Firearms Burst Attack roll.",
	color = Color(255, 125, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(self.color, string.format(self.format,
			speaker:GetName(), text, data.rolltype
		))
	end
})

ix.chat.Register("roll20firearmsburst3", {
	format = "** %s has rolled %s on their Firearms Burst Attack roll.",
	color = Color(255, 125, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(self.color, string.format(self.format,
			speaker:GetName(), text, data.rolltype
		))
	end
})
--[[
	CHAT: roll20brawling
	DESCRIPTION: Highlights brawling attack rolls.
]]--

ix.chat.Register("roll20brawling", {
	format = "** %s has rolled %s on their Brawling Attack roll.",
	color = Color(255, 125, 50),
	CanHear = ix.config.Get("chatRange", 280),
	deadCanChat = true,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		chat.AddText(self.color, string.format(self.format,
			speaker:GetName(), text, data.rolltype
		))
	end
})