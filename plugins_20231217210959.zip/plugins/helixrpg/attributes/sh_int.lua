ATTRIBUTE.name = "Intelligence"
ATTRIBUTE.description = "Determines how smart your character is."