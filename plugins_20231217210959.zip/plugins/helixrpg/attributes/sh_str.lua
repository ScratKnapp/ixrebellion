ATTRIBUTE.name = "Strength"
ATTRIBUTE.description = "Determines how strong and powerful you are."