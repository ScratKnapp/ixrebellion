ATTRIBUTE.name = "Armor Class"
ATTRIBUTE.description = "Determines how hard you are to hit."
ATTRIBUTE.noStartBonus = true