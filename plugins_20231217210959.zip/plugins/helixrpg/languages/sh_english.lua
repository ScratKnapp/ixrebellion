LANGUAGE = {
	chooseSkills = "refine your skillset",
	chooseBackground = "shape your story",
	background = "Background",
	skills = "Skills",
	feats = "Feats",
	errorInvalidStat = "Provided stat is invalid."
}